# Complete source record — large-prime-desert hostile audit

Date: 19 October 2026.

The seven original mathematical files below are embedded byte-for-byte, not merely
referenced through historical sandbox paths. The latest large-prime packet is
preserved in full. The complete controlling consumer REPORT is included to recover
its actual numerator proof (Section 5.1); unrelated historical consumer claims in
that report are not independently re-certified by this audit.

The new proof in REPORT.md does not depend on the 663 separate support intervals,
pre-effectivity providers, any conjectural prime correlation, or an unseen finite
bank proof. The finite exclusion theorem is preserved as a separately un-replayed
dependency. Its decimal endpoint alone is copied, hashed and checked in the new
verifier. Existing historical claim labels below are historical, not automatically
promoted to the new audit verdict.

External inputs actually used: Dusart arXiv:1002.0442v1, Propositions 3.2 and 5.1,
printed p.4; BMOR arXiv:1802.00085v3, Theorems 1.1–1.2, printed pp.4–5. Primary PDF
page images were inspected. Their complete published proofs are referenced, not
copied or purportedly re-proved. URLs and exact roles are in the new REPORT.md.

The source blocks use explicit UTF-8 byte counts and SHA-256 hashes. The verifier
checks their hashes and may restore them with --extract-sources DIRECTORY.

## Manifest

| Original relative path | Bytes | SHA-256 |
|---|---:|---|
| `original-large-prime-desert/REPORT.md` | 11426 | `9c58b94ed872f233a08866cbc5a21da1f0313c2cc44259d52f630304d2482f2b` |
| `original-large-prime-desert/CLOSING_CONTRACT.md` | 2076 | `0c75807250e9766114f5461d95c7433a92f06956ac7ee8f2ca3fa28f57884542` |
| `original-large-prime-desert/SOURCE_RECORD.md` | 805 | `1e256e6b0f90ad78c69dd6e789f2dd55866c93d5727a14f38908708acd410ca8` |
| `original-large-prime-desert/verify_adjacent.py` | 5850 | `4ae57995e27f49fffd599984a6027d55d50e32d044aa49323bada3fe4d73d8de` |
| `original-large-prime-desert/VERIFICATION.json` | 1017 | `85093f90b4f63b74a44309904c9fceaa0ce623e0c104c721d2193fd7fb042eab` |
| `original-large-prime-desert/SHA256.txt` | 414 | `6dd2474209b060e1beab8d02380cfa78dbb7e50ce5810aabc478af601dd5a273` |
| `original-consumer/REPORT.md` | 23819 | `8bb56127e4269a8124b7a280ed1becb550e93eb0f8b66bb48a4e72e756230499` |

## original-large-prime-desert/REPORT.md

<!-- SOURCE name="original-large-prime-desert/REPORT.md" bytes=11426 sha256=9c58b94ed872f233a08866cbc5a21da1f0313c2cc44259d52f630304d2482f2b -->
````text
# Erdős #287 — effective large-prime-row desert and an adjacent-cofactor closing alternative

**Date:** 19 October 2026  
**Programme:** Effectivity / post-effectivity only

## Verdict

This execution does **not** prove the original weighted prime-output lower bound, the effective infinite tail, or Global Erdős #287.

It does three things.

1. It independently checks the relaxed signed sufficient condition
   \[
   J_*\ge -\frac18MH_B,
   \]
   including the exact remaining margin \(479/100000\).
2. It repairs the stated ordinary \(\vartheta\)-estimate from the published modulus-three BMOR bounds rather than citing a nonexistent modulus-one theorem statement.
3. It proves a new counterexample-dependent structural theorem: every denominator in the physical top range that has a prime divisor above \(50M/(47\log M)\) is forced omitted. Consequently the logarithmic-cofactor set in the top \(17/47\) of the interval is an independent set. This strictly extends the earlier prime-centred two-sided cofactor desert to composite middle terms and to a wider window.

The new theorem produces an exact alternative terminal owner,
\[
\sum_n F_M(n)F_M(n+1)>0,
\]
where \(F_M\) detects integers with logarithmic cofactor. No theorem currently audited here proves this positivity at every post-bank scale. Hence there is no terminal prime-producing PAY in this packet.

---

## 1. Frozen data and the relaxed signed contract

Put
\[
L=\log M\ge1154,\qquad B=\lfloor3L/10\rfloor,
\qquad H_B=\sum_{b\le B}\frac1b.
\]

Retain the exact signed assembly
\[
\mathcal C_\square
=\sum_s\Lambda(s)\widetilde\beta(s)+J_*+\mathcal R_*,
\]
with
\[
\left|\sum_s\Lambda(s)\widetilde\beta(s)-\frac4{15}K_MM\right|
<\frac{MH_B}{100000},
\]
\[
K_M>\frac{49}{100}H_B,
\qquad
|\mathcal R_*|<\frac{13}{15000}MH_B.
\]

Then
\[
\frac4{15}\frac{49}{100}-\frac18-\frac1{100000}-\frac{13}{15000}
=\frac{479}{100000}.
\]
Therefore
\[
\boxed{J_*\ge-\frac18MH_B}
\]
is a sufficient post-bank contract. It would imply
\[
\mathcal C_\square>\frac{479}{100000}MH_B
>M^{87/200}+M^{69/200}
\]
throughout \(L\ge1154\). The last inequality is overwhelmingly strict already at the onset. The contract itself remains unproved.

This replaces \(-MH_B/32\) as the weakest currently audited linear-margin contract. The stronger target remains valid but is not mandatory.

---

## 2. Repair of the ordinary prime-counting citation

The relevant BMOR theorem is stated for arithmetic progressions with modulus \(q\ge3\). For \(q=3\), both reduced residue classes satisfy, for \(x\ge8\cdot10^9\),
\[
\left|\vartheta(x;3,a)-\frac x2\right|
<\frac{x}{840\log x},\qquad a=1,2.
\]
Since
\[
\vartheta(x)=\vartheta(x;3,1)+\vartheta(x;3,2)+\log3,
\]
one obtains
\[
|\vartheta(x)-x|
<\frac{x}{420\log x}+\log3
<\frac{x}{400\log x}
\qquad(x\ge8\cdot10^9).
\]
The final comparison is elementary and is checked in the verifier. Thus the ordinary \(\vartheta\)-bound used by the semiprime-sector calculation is recoverable from the literal published theorem; it should not be quoted as BMOR's direct \(q=1\) statement.

The smooth constants remain
\[
\int_{1/2}^1w(t)\,dt=\frac4{15},
\qquad
\int_{1/2}^1t|w'(t)|\,dt=\frac32.
\]

---

## 3. Banked numerator input

For an integer \(h\ge1\), put
\[
L_h=\operatorname{lcm}(1,\ldots,h),
\qquad
T_h=L_h\sum_{j=1}^h\frac1j.
\]

The incoming effective numerator lemma is retained:
\[
\boxed{
1\le h\le\frac{47L}{50}
\quad\Longrightarrow\quad
hT_h<\frac M2.
}
\tag{N}
\]

If \(p^2>M\) is prime and
\[
J_p=\{j\le\lfloor M/p\rfloor:pj\in A\},
\]
the \(p\)-row of the reciprocal identity gives
\[
\sum_{j\in J_p}j^{-1}\equiv0\pmod p.
\tag{R}
\]
If \(J_p\ne\varnothing\), clearing denominators produces a positive integer at most \(T_h\), where \(h=\lfloor M/p\rfloor\), divisible by \(p\).

---

## 4. New theorem — effective large-prime-row desert

### Theorem 4.1

Assume that \(A\subseteq\{a,a+1,\ldots,M\}\) is a putative #287 counterexample: \(a,M\in A\),
\[
\sum_{n\in A}\frac1n=1,
\]
and no two consecutive integers of \([a,M]\) are both omitted.

If \(L\ge1154\), then
\[
\boxed{
 n\in A\quad\Longrightarrow\quad
 P^+(n)<\frac{50M}{47L}.
}
\tag{4.1}
\]
Equivalently, every physical integer divisible by a prime
\[
p\ge\frac{50M}{47L}
\]
is forced omitted.

### Proof

Let \(p\mid n\) be prime with \(p\ge50M/(47L)\), and put
\[
h=\left\lfloor\frac Mp\right\rfloor.
\]
Then
\[
h\le\frac{47L}{50}.
\]
At \(L\ge1154\), \(p>\sqrt M\), since
\[
e^{L/2}>\frac{47L}{50}.
\]
Thus the row congruence (R) is valid.

If \(n\in A\), the row is nonempty. Since
\[
p>\frac M{h+1}\ge\frac M{2h}
\]
and (N) gives \(T_h<M/(2h)\), one has \(p>T_h\). This contradicts the existence of a positive row numerator divisible by \(p\) and at most \(T_h\). Hence \(n\notin A\). QED.

### Remarks

* The theorem is deterministic under the actual counterexample hypothesis.
* It uses the already-paid numerator estimate; it is not a new prime-distribution theorem.
* It applies to composite denominators as well as primes.

---

## 5. Corollary — the \(30/47\) logarithmic-cofactor desert

For \(n\ge2\), define
\[
c(n)=\frac{n}{P^+(n)}.
\]

### Corollary 5.1

The reciprocal-sum condition gives \(a\le\lfloor M/2\rfloor\): indeed, distinct denominators make \(1<|A|/a\le(M-a+1)/a\). Hence the entire window below is physical.

Under the hypotheses of Theorem 4.1, if
\[
\left\lceil\frac{30M}{47}\right\rceil\le n\le M,
\qquad c(n)\le2B,
\]
then \(n\notin A\).

Indeed,
\[
P^+(n)=\frac n{c(n)}
\ge\frac{(30/47)M}{2B}
\ge\frac{50M}{47L},
\]
because \(2B\le3L/5\).

Consequently
\[
\boxed{
\mathcal G_M:=
\left\{n\in\left[\left\lceil\frac{30M}{47}\right\rceil,M\right]:
 c(n)\le2B\right\}
\text{ contains no consecutive integers.}
}
\tag{5.1}
\]
In fact \(c(M)>47L/50>2B\), because \(M\) itself is selected and Theorem 4.1 gives \(P^+(M)<50M/(47L)\).

This widens the earlier \(2M/3\) prime-centred window to \(30M/47\), and it permits both members of the adjacent pair to be composite.

### Recovery of the earlier two-sided prime blocker

If \(p\) is prime and both \(p\) and the relevant neighbour belong to the top window, then \(c(p)=1\), so \(p\) is omitted and a logarithmic-cofactor neighbour would create two adjacent omissions. Explicitly, a counterexample forces
\[
c(p+1)>2B
\quad\left(\left\lceil\frac{30M}{47}\right\rceil\le p<M\right),
\]
and
\[
c(p-1)>2B
\quad\left(\left\lceil\frac{30M}{47}\right\rceil+1\le p\le M\right).
\]
This strictly widens the old \((2M/3,M)\) formulation, up to the unavoidable one-integer lower-endpoint convention.

---

## 6. Exact alternative closing owner

Define the nonnegative weight
\[
F_M(n)=
\sum_{\substack{c\le2B\\n=cp,\ p\text{ prime}}}\log p.
\tag{6.1}
\]

On the interval \(n\ge30M/47\), a representation in (6.1) is unique. If
\[
cp=c'q,
\qquad c,c'\le2B,
\]
with distinct primes \(p,q\), then \(p\mid c'\), \(q\mid c\), and hence
\[
n\le(2B)^2,
\]
contradicting \(30M/47>(2B)^2\) on \(L\ge1154\).

Thus
\[
F_M(n)>0\quad\Longleftrightarrow\quad c(n)\le2B
\]
in the top window. Corollary 5.1 gives the exact counterexample implication
\[
\boxed{
\operatorname{Gap2CE}(M)
\Longrightarrow
\sum_{\lceil30M/47\rceil\le n<M}
F_M(n)F_M(n+1)=0.
}
\tag{6.2}
\]

Therefore the following every-scale theorem would close the tail:
\[
\boxed{
\forall M>U_{\rm fin},\qquad
\sum_{\lceil30M/47\rceil\le n<M}
F_M(n)F_M(n+1)>0.
}
\tag{AC-287}
\]

A positive term is exactly a solution
\[
 n=ap,
 \qquad n+1=bq,
 \qquad 1\le a,b\le2B,
 \qquad p,q\text{ prime},
\]
or
\[
\boxed{bq-ap=1.}
\tag{6.3}
\]

Every earlier two-sided prime witness supplies such a term by taking one of \(a,b\) equal to one. The reverse implication is false: both adjacent integers may be composite.

Finite interface examples are
\[
668=4\cdot167,
\qquad669=3\cdot223,
\]
and
\[
66685=5\cdot13337,
\qquad66686=2\cdot33343.
\]
They are diagnostic fixtures below the bank, not tail evidence.

---

## 7. A paid first moment — and its exact capacity failure

The ordinary prime-counting estimate from Section 2 gives an effective lower bound for the total one-point mass in the new window.

### Theorem 7.1

For every \(L\ge1154\),
\[
\boxed{
\sum_{\lceil30M/47\rceil\le n\le M}F_M(n)
>\frac13MH_{2B}.
}
\tag{7.1}
\]

### Proof

Let \(\alpha=30/47\). For every \(c\le2B\), all relevant prime endpoints exceed \(8\cdot10^9\), and
\[
\begin{aligned}
\sum_{\alpha M<cp\le M}\log p
&=\vartheta(M/c)-\vartheta(\alpha M/c)\\
&>\frac Mc\left[
1-\alpha-
\frac{1+\alpha}{400\lambda_0}
\right],
\end{aligned}
\]
where
\[
\lambda_0=L-\log(2B)+\log\alpha>0.99L.
\]
Since
\[
\frac{17}{47}-\frac1{198L}>\frac13
\qquad(L\ge1154),
\]
summing over \(c\le2B\) proves (7.1). QED.

### Why this still does not close

Since \(F_M(n)\le L\) and the support is unique,
\[
|\mathcal G_M|>rac{MH_{2B}}{3L}.
\]
But a no-adjacent subset of the window can have approximately
\[
\frac12\left(1-\frac{30}{47}\right)M
=\frac{17}{94}M
\]
points. At the onset, the proved support lower bound is far below this path capacity.

Equivalently, the first moment does not imply the adjacent correlation (AC-287). A genuinely two-point arithmetic estimate is still required.

---

## 8. Literature and method audit

The closest recent results do not pay (AC-287):

1. The 2026 joint Dickman-law manuscript proves an ordinary joint limit for **fixed** normalized largest-prime-factor thresholds. Its introduction expressly does not claim a quantitative error or uniformity for parameters moving toward one. The threshold in (AC-287) is
   \[
   P^+(n)>\frac{n}{O(\log M)},
   \]
   whose normalized exponent tends to one.
2. The Lü--Wang--Wu Hardy--Littlewood--Chowla theorem proves cancellation of \(\mu(p+2)\) on primes for a fixed additive shift. It does not count the determinant family \(bq-ap=1\) with two prime variables and logarithmically growing coefficients.
3. Fixed-power results such as \(P^+(p-1)>p^{0.679}\) infinitely often are much weaker than a cofactor \(O(\log p)\), and do not give every-scale interval coverage.

Thus (AC-287) is a legitimate weaker direct contradiction route, but remains a binary prime-correlation problem. No audited source here supplies an effective theorem from \(M=U_{\rm fin}+1\).

---

## 9. Status ledger

### What done

* The relaxed signed contract \(J_*\ge-MH_B/8\) is numerically verified and replaces the unnecessarily strong \(-MH_B/32\) contract.
* The BMOR modulus-one \(\vartheta\) bound is repaired via the two modulus-three residue classes.
* New paper-level theorem: every physical denominator with a prime factor above \(50M/(47L)\) is omitted.
* New paper-level corollary: the logarithmic-cofactor set in \([30M/47,M]\) contains no adjacent pair; the two-sided prime desert is widened and generalized to composite middle terms.
* The one-point mass of this set is paid effectively: \(>MH_{2B}/3\).

### What remains

**OPEN:** prove the adjacent correlation (AC-287), prove an effective original prime-output lower bound, prove the relaxed one-sided \(J_*\) contract, or derive another complete counterexample-dependent contradiction. Effective tail and Global #287 are not proved.

### Next frontier

Attack the literal determinant family
\[
bq-ap=1,
\qquad a,b\le2B,
\]
in the complete upper window, or prove a different theorem forcing two adjacent members of \(\mathcal G_M\). This requires genuine two-point prime arithmetic; the paid first moment and the composite Vaughan cancellations cannot substitute for it.

````
<!-- END SOURCE -->

## original-large-prime-desert/CLOSING_CONTRACT.md

<!-- SOURCE name="original-large-prime-desert/CLOSING_CONTRACT.md" bytes=2076 sha256=0c75807250e9766114f5461d95c7433a92f06956ac7ee8f2ca3fa28f57884542 -->
````text
# Erdős #287 — large-prime-row / adjacent-cofactor closing contract

## Frozen terminal alternatives

For every integer `M>U_fin`, prove one of:

1. `C_sq(M)>=M^(87/200)+M^(69/200)`;
2. the relaxed signed contract `J_*(M)>=-M H_B/8`;
3. the adjacent-cofactor theorem `(AC-287)` below;
4. the inherited two-sided prime witness;
5. another complete contradiction under `Gap2CE(M)`.

Then splice without a gap to the certified finite exclusion.

## Newly paid structural theorem

Let `L=log M>=1154`, `B=floor(3L/10)`, and assume the banked numerator lemma

    h T_h < M/2  for 1<=h<=47L/50.

Under `Gap2CE(M)`, every physical denominator divisible by a prime

    p >= 50M/(47L)

is omitted.

Consequently every integer

    ceil(30M/47) <= n <= M,
    n/P^+(n) <= 2B

is omitted, and no two such integers are consecutive.

## Exact new alternative owner

Define

    F_M(n)=sum_(c<=2B, n=c p, p prime) log p.

On the top window this representation is unique. It is sufficient to prove

    sum_(ceil(30M/47)<=n<M) F_M(n) F_M(n+1) > 0

for every `M>U_fin`.

A positive term is exactly a solution

    b q - a p = 1,
    a,b<=2B,
    p,q prime,

with both adjacent outputs in the physical top window.

## Paid first moment, unpaid correlation

The effective one-point estimate is

    sum_(ceil(30M/47)<=n<=M) F_M(n) > M H_(2B)/3.

This does not force an adjacent pair: its support lower bound remains below the independent-set capacity of the window. No first-moment argument is to be promoted to `(AC-287)`.

## Signed route

The revised sufficient contract

    J_* >= -M H_B/8

is valid because the exact remaining coefficient is `479/100000`. It is still unproved.

## Status

BANK retained: consumer, square correction, finite-bank status, comparison, signed assembly, numerator lemma.

New paper-level PAY: large-prime-row omission theorem, `30/47` adjacent-cofactor desert, effective first moment.

OPEN: adjacent two-point correlation, original prime-output mass, relaxed signed theorem, two-sided supply, or complete direct contradiction. Global #287 remains open.

````
<!-- END SOURCE -->

## original-large-prime-desert/SOURCE_RECORD.md

<!-- SOURCE name="original-large-prime-desert/SOURCE_RECORD.md" bytes=805 sha256=1e256e6b0f90ad78c69dd6e789f2dd55866c93d5727a14f38908708acd410ca8 -->
````text
# Source record

This packet continues the effectivity/post-effectivity line only.

Immediate controlling local files:

- `/mnt/data/erdos287_joint_signed_sector_20261019/REPORT.md`
- `/mnt/data/erdos287_joint_signed_sector_20261019/CLOSING_CONTRACT.md`
- `/mnt/data/erdos287_raw_signed_lift_20261018/REPORT.md`
- `/mnt/data/貼上的文字 (1)(20261018-180259).txt`

The mathematical inputs retained rather than reproved are:

1. the effective consumer and exact finite-bank status;
2. the numerator lemma `h T_h < M/2` for `h<=47 log(M)/50`;
3. the normalized comparison estimates and signed assembly;
4. BMOR's explicit modulus-three prime-progression estimates.

The present verifier checks finite interfaces, constants and examples. It does not recertify those external or inherited analytic inputs.

````
<!-- END SOURCE -->

## original-large-prime-desert/verify_adjacent.py

<!-- SOURCE name="original-large-prime-desert/verify_adjacent.py" bytes=5850 sha256=4ae57995e27f49fffd599984a6027d55d50e32d044aa49323bada3fe4d73d8de -->
````text
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise RuntimeError(msg)


def is_prime(n: int) -> bool:
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    p = 3
    while p * p <= n:
        if n % p == 0:
            return False
        p += 2
    return True


def factor(n: int) -> dict[int, int]:
    out: dict[int, int] = {}
    p = 2
    while p * p <= n:
        while n % p == 0:
            out[p] = out.get(p, 0) + 1
            n //= p
        p = 3 if p == 2 else p + 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def largest_prime_factor(n: int) -> int:
    return max(factor(n))


def lcm(a: int, b: int) -> int:
    return a // math.gcd(a, b) * b


def T(h: int) -> int:
    Lh = 1
    for j in range(1, h + 1):
        Lh = lcm(Lh, j)
    return sum(Lh // j for j in range(1, h + 1))


def harmonic(n: int) -> Fraction:
    return sum((Fraction(1, j) for j in range(1, n + 1)), Fraction())


def scalar_checks() -> dict[str, object]:
    L = 1154
    B = (3 * L) // 10
    alpha = Fraction(30, 47)

    require(Fraction(3, 5) * Fraction(47, 30) == Fraction(47, 50), "window/height identity")
    require(3 * B <= Fraction(47 * L, 50), "legacy 2B window fits numerator range")
    require((1 << (L // 2)) > Fraction(47 * L, 50), "large-prime threshold exceeds sqrt(M)")
    require(alpha > Fraction(1, 2), "physical window starts above M/2")

    margin = Fraction(4, 15) * Fraction(49, 100) - Fraction(1, 8) - Fraction(1, 100000) - Fraction(13, 15000)
    require(margin == Fraction(479, 100000), "relaxed contract margin")

    first_moment_coefficient = Fraction(17, 47) - Fraction(1, 198 * L)
    require(first_moment_coefficient > Fraction(1, 3), "first-moment coefficient")

    x = 8_000_000_000
    require(math.log(3) < x / (8400 * math.log(x)), "BMOR q=3 to q=1 repair")
    require(math.log(alpha.numerator / alpha.denominator) + L - math.log(2 * B) > 0.99 * L,
            "prime endpoint above 0.99L")
    require(math.exp(-113 * L / 200) + math.exp(-131 * L / 200) < float(margin),
            "terminal exponent margin")

    return {
        "L": L,
        "B": B,
        "alpha": "30/47",
        "relaxed_margin": str(margin),
        "first_moment_coefficient_lower": str(first_moment_coefficient),
        "H_2B_float": float(harmonic(2 * B)),
    }


def check_fixture(M: int, B: int, n: int) -> dict[str, int]:
    p = largest_prime_factor(n)
    c = n // p
    h = M // p
    require(c <= 2 * B, f"fixture cofactor {n}")
    require(n * 47 >= 30 * M, f"fixture window {n}")
    require(is_prime(p), f"fixture prime {p}")
    require(p > T(h), f"fixture numerator obstruction {n}")
    return {"n": n, "p": p, "c": c, "h": h, "T_h": T(h)}


def fixture_checks() -> list[dict[str, int]]:
    rows = [
        check_fixture(1000, 2, 668),
        check_fixture(1000, 2, 669),
        check_fixture(100000, 3, 66685),
        check_fixture(100000, 3, 66686),
    ]
    require(3 * 223 - 4 * 167 == 1, "first determinant fixture")
    require(2 * 33343 - 5 * 13337 == 1, "second determinant fixture")
    return rows


def uniqueness_checks() -> int:
    checked = 0
    for M, B in [(1000, 2), (10000, 3), (100000, 3)]:
        reps: dict[int, list[tuple[int, int]]] = {}
        lo = (30 * M + 46) // 47
        for c in range(1, 2 * B + 1):
            for p in range(2, M // c + 1):
                if not is_prime(p):
                    continue
                n = c * p
                if lo <= n <= M:
                    reps.setdefault(n, []).append((c, p))
        for n, rs in reps.items():
            require(len(rs) == 1, f"nonunique representation at {M},{n}: {rs}")
            checked += 1
    return checked


def row_numerator_checks(limit_h: int = 9) -> int:
    checked = 0
    for h in range(1, limit_h + 1):
        Th = T(h)
        for mask in range(1, 1 << h):
            Lh = 1
            for j in range(1, h + 1):
                Lh = lcm(Lh, j)
            N = sum(Lh // j for j in range(1, h + 1) if mask & (1 << (j - 1)))
            require(0 < N <= Th, "subset numerator range")
            checked += 1
    return checked


def mutation_checks() -> list[str]:
    L = 1154
    false_claims = {
        "window_3_over_5_supports_full_2B": Fraction(3, 5) >= Fraction(30, 47),
        "relaxed_contract_minus_one_seventh": (
            Fraction(4, 15) * Fraction(49, 100)
            - Fraction(1, 7)
            - Fraction(1, 100000)
            - Fraction(13, 15000)
            > 0
        ),
        "first_moment_forces_half_density": Fraction(1, 3) / L >= Fraction(17, 94),
        "wrong_fixture_determinant_sign": 3 * 223 - 4 * 167 == -1,
        "old_integral_only_row_claim": T(6) < 100,
    }
    rejected: list[str] = []
    for name, claim in false_claims.items():
        require(not claim, f"mutation unexpectedly accepted: {name}")
        rejected.append(name)
    return rejected


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", default="verification.json")
    args = ap.parse_args()

    result = {
        "scalar_checks": scalar_checks(),
        "fixtures": fixture_checks(),
        "uniqueness_records_checked": uniqueness_checks(),
        "row_subset_numerators_checked": row_numerator_checks(),
        "mutations_rejected": mutation_checks(),
        "scope": "finite regression and scalar gates only; numerator lemma and prime-distribution inputs remain external",
    }
    raw = json.dumps(result, indent=2, sort_keys=True).encode() + b"\n"
    Path(args.output).write_bytes(raw)
    print(hashlib.sha256(raw).hexdigest())


if __name__ == "__main__":
    main()

````
<!-- END SOURCE -->

## original-large-prime-desert/VERIFICATION.json

<!-- SOURCE name="original-large-prime-desert/VERIFICATION.json" bytes=1017 sha256=85093f90b4f63b74a44309904c9fceaa0ce623e0c104c721d2193fd7fb042eab -->
````text
{
  "fixtures": [
    {
      "T_h": 137,
      "c": 4,
      "h": 5,
      "n": 668,
      "p": 167
    },
    {
      "T_h": 25,
      "c": 3,
      "h": 4,
      "n": 669,
      "p": 223
    },
    {
      "T_h": 1089,
      "c": 5,
      "h": 7,
      "n": 66685,
      "p": 13337
    },
    {
      "T_h": 3,
      "c": 2,
      "h": 2,
      "n": 66686,
      "p": 33343
    }
  ],
  "mutations_rejected": [
    "window_3_over_5_supports_full_2B",
    "relaxed_contract_minus_one_seventh",
    "first_moment_forces_half_density",
    "wrong_fixture_determinant_sign",
    "old_integral_only_row_claim"
  ],
  "row_subset_numerators_checked": 1013,
  "scalar_checks": {
    "B": 346,
    "H_2B_float": 7.117523989848874,
    "L": 1154,
    "alpha": "30/47",
    "first_moment_coefficient_lower": "3884317/10739124",
    "relaxed_margin": "479/100000"
  },
  "scope": "finite regression and scalar gates only; numerator lemma and prime-distribution inputs remain external",
  "uniqueness_records_checked": 9531
}

````
<!-- END SOURCE -->

## original-large-prime-desert/SHA256.txt

<!-- SOURCE name="original-large-prime-desert/SHA256.txt" bytes=414 sha256=6dd2474209b060e1beab8d02380cfa78dbb7e50ce5810aabc478af601dd5a273 -->
````text
9c58b94ed872f233a08866cbc5a21da1f0313c2cc44259d52f630304d2482f2b  REPORT.md
0c75807250e9766114f5461d95c7433a92f06956ac7ee8f2ca3fa28f57884542  CLOSING_CONTRACT.md
1e256e6b0f90ad78c69dd6e789f2dd55866c93d5727a14f38908708acd410ca8  SOURCE_RECORD.md
4ae57995e27f49fffd599984a6027d55d50e32d044aa49323bada3fe4d73d8de  verify_adjacent.py
85093f90b4f63b74a44309904c9fceaa0ce623e0c104c721d2193fd7fb042eab  VERIFICATION.json

````
<!-- END SOURCE -->

## original-consumer/REPORT.md

<!-- SOURCE name="original-consumer/REPORT.md" bytes=23819 sha256=8bb56127e4269a8124b7a280ed1becb550e93eb0f8b66bb48a4e72e756230499 -->
````text
# Erdős #287 — Effective consumer refinement on the unchanged prime source

**Date:** 17 October 2026 (Hong Kong/Taiwan programme date).  
**Scope:** the independent effectivity route only.  
**Verdict:** two quantitative consumer improvements are proved below at manuscript/computational-certificate level. **No new positive prime-output estimate, effective infinite-tail exclusion, or global proof is obtained.**

This report follows the requested Gold A / Gold B experiments. Gold B, effective consumer redesign, yields an improved full-source pollution allowance and a substantially larger deterministically certified subsource. Gold A does not yield the needed signed prime-producing estimate. The remaining prime theorem is stated explicitly, not treated as an established input.

No Aristotle/SourceChain theorem is changed or used as an unpaid hypothesis. No counterexample finite bank is extended or replayed, no Lean build is claimed, and no historical-priority or independent-referee claim is made. The methods of empty prime rows, harmonic-subsum support counting, and one-pair consumers already occur in the predecessor sources. The advances claimed here are the explicit parameter refinements and their proved consequences, relative to those recovered sources.

## 1. Exact source and controlling predecessor results

All logarithms are natural. Let M be a positive integer and put

\[
L=\log M\ge1154,\qquad H=\lfloor3L/2\rfloor,\qquad
B=\lfloor H/5\rfloor=\lfloor3L/10\rfloor.
\]

The floor identity follows because, for an integer d>0, floor(floor(x)/d)=floor(x/d). Retain

\[
w(t)=256(t-1/2)^2(1-t)^2\mathbf1_{[1/2,1]}(t),
\]
\[
a_M(r)=w(r/M)\sum_{\substack{1\le b\le B,\ q\ {m prime}\\r=2bq+1}}\log q,
\quad G_{\rm pr}=\sum_{r\ {m prime}}a_M(r),
\quad \mathcal P_M=\sum_r a_M(r)\Lambda(r).
\tag{1.1}
\]

Here 0<=w<=1, and positive weight is equivalent to M/2<r<M. Every input q is a genuine prime. The b-range, weight, shift, and original source in (1.1) are unchanged throughout the full-source theorem.

A counterexample with maximum M means a finite set A of integers, with a=min A>=2, max A=M, sum of reciprocals exactly one, and every consecutive selected gap at most two. Such a set has at least two terms and

\[
1<|A|/a\le(M-a+1)/a,\qquad a\le\lfloor M/2\rfloor.
\tag{1.2}
\]

The inherited contamination construction used the common row height H and proved an allowance less than M^(11/20). The original positive-supply inequality itself was not proved. The recovered October 11 one-pair handoff already certified the smaller subsource b<=floor(L/(5 log L)); it did not prove that a pair exists at every scale. The recovered R11 report preserved its prime-weighted source, exact parity identity, and export error <2*10^-240 N_M, but did not prove its closing antecedent. Complete available texts are embedded in SOURCE_RECORD.md.

## 2. The exact original source only needs row height 4B

### Lemma 2.1 — integral row-length bound

For every positive-weight record r=2bq+1 in (1.1),

\[
\boxed{\lfloor M/q\rfloor\le4b\le K,\qquad K:=4B.}
\tag{2.1}
\]

**Proof.** M<2r and both are integers, so M<=2r-1=4bq+1. Since q>=2, M/q<=4b+1/q<4b+1. Taking floors proves (2.1). The stronger bound 4b-1 is false, even with both primes genuine: b=1,q=83,r=167,M=333 has floor(M/q)=4. This is a small regression, not a post-bank counterexample.

For L>=1154,

\[
B\ge346,\qquad 1384\le K\le6L/5.
\tag{2.2}
\]

The following geometric side conditions hold throughout the same range:

\[
(K+1)^2<M,\qquad M\ge64B^2.
\tag{2.3}
\]

For example they hold at L=1154 with exp(1154)>2^1154, and the exponential divided by the relevant quadratic is increasing. Consequently every record has

\[
q>(M-2)/(4B)>\sqrt M>K,
\qquad q>y:=M/(K+1).
\tag{2.4}
\]

For the middle inequality in (2.4), write t=sqrt M>=8B; then t^2-4Bt-2>0. The last inequality also follows directly from (2.1).

This use of K=4B rather than H is the source of the improved full-source exponent. It does not replace the prime sequence by a surrogate.

## 3. A complete support certificate from h=1384

Define the number of distinct harmonic subsums

\[
s(h)=\#\{\sum_{j\in J}1/j:J\subseteq\{1,\ldots,h\}\}.
\]

### Theorem 3.1

\[
\boxed{s(h)<2^{h/2}\quad\text{for every integer }h\ge1384.}
\tag{3.1}
\]

The prior gate started at h=1500. The following proof regenerates the complete finite portion from 1384 and supplies the analytic infinite continuation. It is an auxiliary row-height certificate, **not** a new range of counterexample maxima M checked by finite search.

### 3.1 Exact finite bound

For 2<=Y<=h put

\[
D_{h,Y}=\prod_{p\le Y}p^{\lfloor\log_p h\rfloor},\qquad
r_{h,Y}=\#\{n\le h:P^+(n)>Y\}.
\]

All Y-smooth denominators divide D_(h,Y). Their reciprocal subsums have denominator dividing D_(h,Y) and lie between zero and the harmonic sum. The other denominators give at most 2^r different sums. Thus

\[
s(h)\le2^{r_{h,Y}}\bigl(D_{h,Y}\operatorname{bitlength}(h)+1\bigr)=:U(h,Y).
\tag{3.2}
\]

The harmonic bound follows by splitting denominators into dyadic blocks, each with reciprocal sum at most one. If Y^2>h, a denominator has at most one prime factor greater than Y, with exponent one. Hence

\[
r_{h,Y}=\sum_{j=1}^{\lfloor h/(Y+1)\rfloor}
\left[\pi(\lfloor h/j\rfloor)-\pi(Y)\right].
\tag{3.3}
\]

Starting with a=1384, repeatedly set

```
b=min(2^20-1, a+max(1,floor(a/100)))
Y=floor(b/8)
```

and verify, in integers,

\[
U(b,Y)^2<2^a.\tag{3.4}
\]

Then s(h)<=s(b)<=U(b,Y)<2^(a/2)<=2^(h/2) for every integer h in [a,b]. Set a=b+1 and continue. The accompanying program regenerates the sieve of Eratosthenes through 2^20-1, exact prime powers, lattice products, and every comparison. All **663 intervals** pass, cover exactly **1,047,192 integers** from 1384 through 1,048,575, and have no gaps. The minimum recorded square slack is 25 bits. SUPPORT_CERTIFICATE.json records the intervals, counts, product hashes and slack; the program recomputes the products rather than trusting those hashes.

### 3.2 Infinite continuation, with a published input

Dusart [D], Theorem 6.9 (6.5), gives

\[
\pi(x)\ge\frac{x}{\log x}\left(1+\frac1{\log x}\right)\quad(x\ge599),
\qquad
\pi(x)\le\frac{x}{\log x}\left(1+\frac{1.2762}{\log x}\right)\quad(x>1).
\]

In particular x/log x<=pi(x)<=5x/(4 log x) for x>=2^17. This weakening uses log2>69/100. The published statement and domains were inspected on PDF page 9 (zero-based page 8). Its proof and external computational inputs are not independently reproduced by our checker.

For h>=2^20 divisible by eight, set Y=h/8. Equation (3.3) gives

\[
\frac{r_{h,Y}}h\le\frac{265/112}{\log(h/8)}.
\tag{3.5}
\]

Indeed r=sum_(j=1)^7 pi(h/j)-7pi(h/8), and (5/4)sum_(j=1)^7 1/j-7/8=265/112.

We also need the elementary bound lcm(1,...,n)<=4^(n-1). For even and odd n it follows inductively from

```
lcm(1,...,2n) divides lcm(1,...,n) * binomial(2n,n),
lcm(1,...,2n+1) divides lcm(1,...,n+1) * binomial(2n+1,n).
```

A prime power newly above the smaller lcm contributes a positive binomial valuation; the binomial bounds are at most 4^n in each case. Thus theta(t)<=(log4)t. Separating the first prime power, the square, and the remaining powers in D_(h,h/8) gives

\[
\frac{\log_2D_{h,h/8}}h\le
2\left(\frac18+h^{-1/2}+(\log_2h)h^{-2/3}\right).
\]

Using the sharper harmonic bound 1+log h in (3.2),

\[
\frac{\log_2s(h)}h\le
\frac{265/112}{\log(h/8)}+
2\left(\frac18+h^{-1/2}+(\log_2h)h^{-2/3}\right)
+\frac{\log_2(2+\log h)}h.
\tag{3.6}
\]

Each nonconstant term decreases for h>=2^20. At 2^20 a rational upper bound is

\[
\frac{265/112}{17(69/100)}
+2\left(\frac18+\frac1{1024}+\frac{20}{8192}\right)
+\frac4{2^{20}}
=\frac{987014419}{2152464384}<\frac{47}{100}.
\tag{3.7}
\]

Here h^(2/3)>8192 and 2+log h<16 were deliberately weakened. For arbitrary h>=2^20, round upward to a multiple of eight h'<=h+7. Monotonicity gives s(h)<=s(h')<2^(.47h')<2^(h/2), since .47(h+7)<h/2 on this range. Together with the finite certificates this proves Theorem 3.1.

## 4. Full-source contamination below M^(87/200)

Write

\[
D_K=\operatorname{lcm}(1,\ldots,K),\qquad
T_K=D_K\sum_{j=1}^K1/j\in\mathbb Z_{>0}.
\]

Let Bad_K be the union of the prime divisors of the distinct positive integers

\[
\mathcal V_K^+=\{D_K\sum_{j\in J}1/j:\varnothing\ne J\subseteq[1,K]\}.
\]

There are s(K)-1 of these integers and each is at most T_K. The product of the distinct bad primes greater than y divides the product of these numerators, so

\[
\#\{q\in\mathrm{Bad}_K:q>y\}
\le Q_K(y):=(s(K)-1)\frac{\log T_K}{\log y}.
\tag{4.1}
\]

The empty subset contributes zero, and is excluded from the numerator product.

### 4.1 Why a good prime row is actually empty

Suppose A has reciprocal sum one, q>sqrt M, q>K, floor(M/q)<=K and q not in Bad_K. Reducing q times the reciprocal sum modulo q is legitimate in the ring of rationals with denominator coprime to q. All terms not divisible by q vanish; the remaining terms give

\[
\sum_{j:qj\in A}j^{-1}\equiv0\pmod q.
\tag{4.2}
\]

Since q>K, D_K is a unit modulo q. A nonempty row would give a positive integer in V_K^+ divisible by q, contradicting goodness. Therefore every q-multiple in A is absent. This argument includes the complete row, not a truncated list of its selected entries.

An output prime r>M/2 has only the singleton multiple r below M, so its row is empty independently of Bad_K. Thus a good input producing a genuine output prime forces both r-1=2bq and r to be omitted. By (1.2), r-1>=a, and r<M. If r-1=a there is an immediate endpoint contradiction; otherwise these two consecutive omissions have selected positions on both sides and force a gap at least three.

### 4.2 Output prime powers and multiplicities are paid

For positive-weight records, q>sqrt M>B. The map (b,q)->bq is injective on the source: if bq=b'q' and q differs from q', then q divides b'<=B, impossible.

If r=ell^j, j>=2, is a proper prime power, then ell<=sqrt M<q. Since ell-1 divides 2bq and is coprime to q, ell-1 divides 2b; thus the odd base ell is at most 2B+1. There are at most B possible odd bases and, for each base, at most one power in the open interval (M/2,M). By injectivity, each has only one source record. Therefore

\[
\mathcal P_{M,\mathrm{proper\ power}}\le BL\log(2B+1).
\tag{4.3}
\]

Each bad input has at most B output records, each of weight at most L^2. Consequently, if a counterexample exists at M,

\[
\mathcal P_M\le
BL\log(2B+1)+BL^2Q_K(y)=:E_{\rm new}(M).
\tag{4.4}
\]

The decomposition distinguishes genuine prime output from Mangoldt-supported proper powers. A regression such as 2187=2*1093+1=3^7 shows why the latter cannot simply be dropped.

### 4.3 Explicit every-M exponent

For every L>=1154,

\[
\log(K+1)\le L/100,\qquad \log(2B+1)\le L/100.
\tag{4.5}
\]

The first follows from K<=1.2L, exp(8)>1.2*1154+1, and monotonicity of L/100-log(1.2L+1); the second is weaker. The lcm bound and harmonic sum<=K give

\[
\log T_K\le(K-1)\log4+\log K<1.69L,
\qquad \log y\ge.99L.
\]

Here log2<.7, and 1.69/.99<2. By Theorem 3.1 and log2<347/500,

\[
Q_K(y)<2s(K)<2\,2^{K/2}<2M^{1041/2500}.
\tag{4.6}
\]

Using B<=.3L,

\[
E_{\rm new}(M)
<\left(\frac3{1000}+\frac35\right)L^3M^{1041/2500}
<L^3M^{1041/2500}.
\tag{4.7}
\]

Finally

\[
3\log L<\frac{93}{5000}L\quad(L\ge1154).
\]

At the initial point, log1154<7.1 gives 3log1154<21.3<(93/5000)*1154=21.4644; the difference has positive derivative 93/5000-3/L. Hence

\[
\boxed{E_{\rm new}(M)<M^{1041/2500+93/5000}=M^{87/200}.}
\tag{4.8}
\]

### Theorem 4.1 — improved consumer on the same full source

For every integer M with log M>=1154,

\[
\boxed{\mathrm{Counterexample}_{287}(M)\Longrightarrow
\mathcal P_M<M^{87/200}.}
\tag{4.9}
\]

Equivalently a lower bound P_M>=M^(87/200) would exclude that M. The old sufficient exponent was 11/20; the new exponent is 87/200. The decrease 23/200 is a genuine reduction in the required pollution allowance. At M>10^501 the ratio of the two power thresholds exceeds 10^57.615. **It is not a prime lower bound and does not by itself exclude any new maximum M.** No optimality of the exponent is claimed.

## 5. A larger subsource with no bad-input allowance

### Lemma 5.1 — effective numerator cutoff

For every L>=1154 and integer 1<=j<=47L/50, put D_j=lcm(1,...,j) and T_j=D_j sum_(i<=j)1/i. Then

\[
\boxed{jT_j<M/2.}\tag{5.1}
\]

**Proof.** By Dusart [D], Propositions 3.2 and 5.1,

\[
\psi(x)<\frac{36261}{36260}x+
\frac{100007}{100000}\sqrt x+\frac{89}{50}x^{1/3}\quad(x>0).
\tag{5.2}
\]

Both propositions and domains were inspected on printed page 4 (zero-based PDF page 3). Since log D_j=psi(j) and the harmonic sum is at most 1+log j,

\[
\log(jT_j)\le\psi(j)+\log j+\log(1+\log j)\le g(L),
\]

where

\[
g(L)=\frac{36261}{36260}\frac{47L}{50}
+\frac{100007}{100000}\sqrt{47L/50}
+\frac{89}{50}(47L/50)^{1/3}
+\log L+\log(1+\log L).
\tag{5.3}
\]

The function (g(L)+1)/L decreases for L>=1154. In addition to the decreasing powers L^-1/2, L^-2/3 and 1/L, this follows for log L/L from log L>1, and for log(1+log L)/L because its derivative has numerator 1/(1+log L)-log(1+log L)<0.

At L=1154, 47L/50<33^2 and <11^3, log1154<71/10, and log(81/10)<21/10. Thus

\[
g(1154)<
\frac{36261}{36260}\frac{47\cdot1154}{50}
+\frac{100007}{100000}33+\frac{89}{50}11
+\frac{71}{10}+\frac{21}{10}
=\frac{207873544603}{181300000}<1153.
\tag{5.4}
\]

It follows that g(L)<L-1 for all L>=1154. Therefore jT_j<exp(L-1)=M/e<M/2. All base-point comparisons in (5.4) are checked with rational arithmetic and Taylor-series bounds. QED.

### 5.2 Full output window, larger cofactor range

Let C(M)=floor(47L/200). For a record with b<=C(M), use j=4b. Then j<=47L/50, floor(M/q)<=j, and

\[
jq=2r-2>M-2>M/2>jT_j.
\]

Thus q>T_j, so no nonempty row numerator can vanish modulo q. Every genuine prime output of this restricted source is already a certified blocker, without subtracting an exceptional-input population.

At the reported bank edge, exact rational enclosures give

\[
B=346,\qquad C(M)=271,
\qquad \left\lfloor\frac{L}{5\log L}\right\rfloor=32.
\tag{5.5}
\]

The old certified range is contained in the new one for all L>=1154, because 1/(5log L)<47/200. The predecessor one-pair mechanism is preserved; its certified cofactor range is enlarged. The values in (5.5) are arithmetic illustrations, not a new certificate of the finite counterexample bank.

### 5.3 Upper output window, every original cofactor

For a record with r>2M/3, put j=3b. Then j<=.9L<.94L and

\[
M<\tfrac32r=jq+\tfrac32,
\qquad \lfloor M/q\rfloor\le j,
\qquad jq>M-\tfrac32>M/2>jT_j.
\]

The floor statement uses integrality: M<=jq+1. Again q>T_j, so the input row is empty. This covers **every original b<=B** when r>2M/3. The output must be a genuine prime; merely having positive von Mangoldt weight is not sufficient.

### Theorem 5.2 — explicitly restricted certified mass

Define, with the original weight and both prime conditions retained,

\[
G_{\rm cert}(M)=
\sum_{b\le B}\sum_{\substack{q\ {m prime}\\r=2bq+1\ {m prime}}}
(\log q)w(r/M)
\mathbf1_{\{b\le\lfloor47L/200\rfloor\ \mathrm{or}\ 3r>2M\}}.
\tag{5.6}
\]

For every integer M with log M>=1154,

\[
\boxed{\mathrm{Counterexample}_{287}(M)\Longrightarrow G_{\rm cert}(M)=0.}
\tag{5.7}
\]

A single positive-weight genuine prime pair in the displayed union region excludes that M. This is a subsource of (1.1), not a redefinition of its full statistic. The lower bound G_cert>0 is not automatically weaker than P_M>=M^(.435), since a total mass lower bound does not by itself locate that mass in the restricted region.

Under a counterexample, all genuine positive-weight output must therefore be confined to the residual wedge

\[
\boxed{\lfloor47L/200\rfloor<b\le B,
\qquad M/2<r\le2M/3.}
\tag{5.8}
\]

This is an exact source-localization consequence. No theorem excluding that concentration, and no effective positive lower bound in the certified region, is proved here. Existing signed estimates cannot be copied to the restriction without checking the new masks and normalization.

## 6. What this changes in R11, and the error floor it does not remove

Retain the original R11 quantities, v=457/1000, N_M=Hcal_M/L, Hcal_M>=2M/15, and

\[
G_{\rm pr}=(S_v-\mathcal L_v)/2,
\qquad |\mathfrak C_v^{(80)}-\mathcal L_v|<\epsilon N_M,
\quad\epsilon=2\cdot10^{-240}.
\tag{6.1}
\]

The complete source, same core and written error proof are supplied in the R11 source records. No additional affine-correlation estimate is imported.

A correction to earlier conversational wording is important. Writing T_v for the rough composite mass gives S_v=G_pr+T_v and L_v=T_v-G_pr. The gap S_v-L_v=2G_pr therefore asks for positive prime mass; it **does not require primes to outweigh semiprimes**.

For M>10^501, the sufficient genuine-prime mass G_pr>delta N_M can now take delta=10^-281. Indeed

\[
\mathcal P_M\ge\log(M/2)G_{\rm pr}
>\delta\mathcal H_M/2\ge\delta M/15>M^{87/200}.
\tag{6.2}
\]

The last inequality follows from (113/200)*501=283.065>283 and 100>15. Hence delta M^(113/200)/15>100/15>1. We have used log(M/2)>=L/2, valid throughout the present range.

For the **unchanged** R11 core, a sufficient antecedent is consequently

\[
\mathfrak C_v^{(80)}(M)\le S_v(M)
-\left(2\cdot10^{-240}+2\cdot10^{-281}\right)N_M
\quad\text{for every integer }M>U_{\rm fin}.
\tag{6.3}
\]

This is weaker than the previous R11 antecedent with 2*10^-224+2*10^-240. But epsilon is much larger than 10^-281. **Dropping epsilon would invalidate the deduction.** The direct source's 57-order power-threshold reduction is not a 57-order improvement in the unchanged core's required precision; its established export error now dominates. We do not change the cutoff S=ceil(L^80), claim a new error estimate, or count (6.3) as a proved signed bound.

The full prime detection remains in the convolution: for genuine input q the only nonzero tuple is (s,k,e)=(1,1,q). The small-variable contribution and the moving roughness mask cannot be discarded. Neither a long-affine unweighted estimate nor a model mass proves (6.3).

## 7. The exact finite splice is still conditional on prime supply

The recovered finite-bank report gives the 502-digit integer U_fin whose full decimal appears in the source archive and checker. Its size, but not its finite exclusion certificate, was checked here. Exact integer comparisons show U_fin>10^501 and U_fin>2^1665; rational log bounds show 1665log2>1154. Therefore every M>U_fin is inside the onset of Theorems 4.1 and 5.2.

Either of the following, **if actually proved**, would now finish the analytic side:

\[
\forall M>U_{\rm fin},\quad\mathcal P_M\ge M^{87/200},
\tag{7.1}
\]

or

\[
\forall M>U_{\rm fin},\quad G_{\rm cert}(M)>0.
\tag{7.2}
\]

Theorem 4.1 or 5.2 would exclude that entire tail. A valid finite exclusion for 2<=M<=U_fin would cover the complementary integers with no endpoint gap. **Neither (7.1), (7.2), nor the R11 antecedent (6.3) is proved here.** The finite certificate's earlier replay status is inherited provenance, not a fresh run or an unconditional Lean theorem in this packet.

The prime-producing framework of Ford–Maynard [FM] requires actual Type I/II hypotheses for the chosen sequence. It does not provide those missing estimates for (1.1) or (5.6). The external literature inspected this turn is not substituted for an unmatched growing-cofactor, weighted, every-M prime theorem.

## 8. Gold outcomes and unresolved work

| Experiment | Actual output | Not obtained |
|---|---|---|
| Gold A: inverse / signed prime supply | The counterexample implication confines genuine output to the explicit wedge (5.8). This is a consequence of the new row certification, not a separate correlation theorem. | A quantitative contradiction to that confinement, a signed prime-producing lower bound, or a proof of (6.3). |
| Gold B: effective consumer redesign | Same full-source allowance <M^(.435), and a larger zero-bad-input certified region, both with onset log M>=1154. | Positivity of the required prime statistic at every scale. |
| Finite splice | Numerical onset compatibility checked against the reported endpoint's integer size. | Fresh finite-bank replay, a new Lean build, and unconditional global closure. |

The new deductions improve the mathematical capacity of the consumer. They are not another fractional word, a larger counterexample finite bank, or a renamed prime estimate. Conversely they do not satisfy the user's global stopping objective: no new post-bank maximum is certified excluded merely by proving these implications. The first unpaid theorem is still a source-valid, effective positive prime-output estimate, now allowed to use the weaker threshold or larger certified region above.

## 9. Reproducibility and scope of the checks

Run with Python 3 standard library only:

```
python -S verify_effectivity.py --outdir normal
python -S -O verify_effectivity.py --outdir optimized
cmp normal/VERIFICATION.json optimized/VERIFICATION.json
cmp normal/SUPPORT_CERTIFICATE.json optimized/SUPPORT_CERTIFICATE.json
```

The two runs were executed and their corresponding files are byte-identical. In addition to the 663 support intervals, there are 58,400 small exact regression cases across the recorded categories. These cases test universal finite identities at small inputs; they are not tests of prime supply at a 502-digit scale.

Six explicit negative controls check an over-short row, a support-coverage gap, an unpaid enlarged cofactor range, omission of the retained R11 error, an actual proper-power output, and the incompatible combination of the historical .414 budget with an extra 1% error. Four deliberately wrong mathematical variants (`height`, `support`, `cutoff`, `export`) were invoked separately in normal and optimized modes; all eight invocations exited with code 2 and the expected rejection message. These are specified negative controls, not a claim of exhaustive software fault coverage.

All acceptance arithmetic is integer or Fraction arithmetic; transcendental endpoint bounds use explicit positive Taylor series and an atanh series with rational remainders. The checker contains no assertion-based acceptance gates, probabilistic prime acceptance, or prime-supply oracle. The infinite monotonicity arguments and the imported published estimates are part of the written proof, not consequences of the regression count.

Five primary deliverables are supplied: REPORT.md, SOURCE_RECORD.md, verify_effectivity.py, SUPPORT_CERTIFICATE.json, and VERIFICATION.json. The root verification file packages the base run's results, actual normal/optimized comparison and mutation receipts, and SHA-256 hashes of the other deliverables. It is intentionally richer than the byte-identical base run summaries.

## 10. Sources and version policy

[D] Pierre Dusart, *Estimates of Some Functions Over Primes without R.H.*, arXiv:1002.0442v1. Propositions 3.2 and 5.1 (printed p.4), and Theorem 6.9 (6.5), printed p.9. Primary PDF: https://arxiv.org/pdf/1002.0442v1 . Used only for the three explicit estimates identified above. The relevant page images were inspected.

[FM] Kevin Ford and James Maynard, *On the theory of prime-producing sieves*, arXiv:2407.14368, introduction and actual Type I/II assumptions. Primary source: https://arxiv.org/html/2407.14368v1 . Consulted for applicability; none of its analytic hypotheses is asserted proved for the present source.

Private predecessor texts and the user's continuation brief are reproduced with original names, byte lengths, and SHA-256 in SOURCE_RECORD.md. These include the original finite-gate proof, the October 11 certified-subsource handoff, and the R11 report/contract. Historical status labels inside them are not newly endorsed. The original full counterexample finite-bank certificate data are not supplied anew by this packet.

````
<!-- END SOURCE -->
